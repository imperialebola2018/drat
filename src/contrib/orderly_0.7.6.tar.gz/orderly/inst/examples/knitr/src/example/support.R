myfunction <- function(a = foo) {
  message("ANSWER:", a * 2)
}
