data <- read.csv("data.csv")

invisible(saveRDS(data, "out.rds"))
