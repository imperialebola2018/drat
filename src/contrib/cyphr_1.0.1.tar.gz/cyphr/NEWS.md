## cyphr 1.0.1

* First CRAN relsease

## cyphr 0.2.0

* Authenticated encryption (with signed messages) is now supported for openssl, and is enabled by default.  Along with this the pack format for openssl has changed which will break *all* existing uses of the package (I don't believe there are any)

## cyphr 0.1.0

* Initial prototype, as sent to rOpenSci onboarding for review
