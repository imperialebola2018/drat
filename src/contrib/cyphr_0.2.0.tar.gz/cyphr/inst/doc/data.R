## ----echo = FALSE, results = "hide"--------------------------------------
local({
  if (!file.exists("alice")) {
    dir.create("alice")
    cyphr::ssh_keygen("alice", FALSE)
  }
  if (!file.exists("bob")) {
    dir.create("bob")
    cyphr::ssh_keygen("bob", FALSE)
  }
  Sys.setenv(USER_KEY = "alice")
  Sys.setenv(USER_PUBKEY = "alice")
  unlink("data", recursive = FALSE)
})
sys_setenv <- function(...) {
  vars <- names(list(...))
  prev <- vapply(vars, Sys.getenv, "", NA_character_)
  Sys.setenv(...)
  prev
}
sys_resetenv <- function(old) {
  i <- is.na(old)
  if (any(i)) {
    Sys.unsetenv(names(old)[i])
  }
  if (any(!i)) {
    do.call("Sys.setenv", as.list(old[!i]))
  }
}

## ------------------------------------------------------------------------
data_dir <- "data"
dir.create(data_dir)
dir(data_dir)

## ------------------------------------------------------------------------
cyphr::data_admin_init(data_dir)

## ------------------------------------------------------------------------
cyphr::data_admin_init(data_dir)

## ------------------------------------------------------------------------
key <- cyphr::data_key(data_dir)

## ------------------------------------------------------------------------
filename <- file.path(data_dir, "iris.rds")
cyphr::encrypt(saveRDS(iris, filename), key)
dir(data_dir)

## ----error = TRUE--------------------------------------------------------
readRDS(filename)

## ------------------------------------------------------------------------
head(cyphr::decrypt(readRDS(filename), key))

## ----error = TRUE--------------------------------------------------------
key_bob <- cyphr::data_key(data_dir, "bob")

## ------------------------------------------------------------------------
cyphr::data_request_access(data_dir, "bob")

## ------------------------------------------------------------------------
req <- cyphr::data_admin_list_requests(data_dir)
req

## ------------------------------------------------------------------------
cyphr::data_admin_authorise(data_dir, yes = TRUE)

## ------------------------------------------------------------------------
cyphr::data_admin_list_requests(data_dir)

## ------------------------------------------------------------------------
cyphr::data_admin_list_keys(data_dir)

## ------------------------------------------------------------------------
key_bob <- cyphr::data_key(data_dir, "bob")
head(cyphr::decrypt(readRDS(filename), key_bob))

## ----echo = FALSE, results = "hide"--------------------------------------
unlink(data_dir, recursive = TRUE)
dir.create(data_dir)

## ------------------------------------------------------------------------
cyphr::data_admin_init(data_dir)

## ------------------------------------------------------------------------
cyphr::encrypt(saveRDS(iris, filename), cyphr::data_key(data_dir))

## ----echo = FALSE--------------------------------------------------------
oo <- sys_setenv(USER_KEY = "bob", USER_PUBKEY = "bob")

## ----echo = TRUE---------------------------------------------------------
hash <- cyphr::data_request_access(data_dir)

## ----echo = FALSE--------------------------------------------------------
sys_resetenv(oo)

## ------------------------------------------------------------------------
cyphr::data_admin_authorise(data_dir, yes = TRUE)

## ----echo = FALSE--------------------------------------------------------
oo <- sys_setenv(USER_KEY = "bob", USER_PUBKEY = "bob")

## ----echo = TRUE---------------------------------------------------------
head(cyphr::decrypt(readRDS(filename), cyphr::data_key(data_dir)))

## ----echo = FALSE--------------------------------------------------------
sys_resetenv(oo)

## ------------------------------------------------------------------------
dir("data", all.files = TRUE, no.. = TRUE)

## ------------------------------------------------------------------------
dir(file.path("data/.cyphr"))
names(cyphr::data_admin_list_keys("data"))

## ------------------------------------------------------------------------
h <- names(cyphr::data_admin_list_keys("data"))[[1]]
readRDS(file.path("data/.cyphr", h))

## ------------------------------------------------------------------------
h

## ----echo = FALSE, results = "hide"--------------------------------------
unlink(data_dir, recursive = TRUE)
unlink("alice", recursive = TRUE)
unlink("bob", recursive = TRUE)

