library(testthat)
library(vdiffr)
library(distcrete)
library(incidence)
library(projections)

test_check("projections")
