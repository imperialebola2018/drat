library(testthat)
library(montagu)

test_check("montagu")
