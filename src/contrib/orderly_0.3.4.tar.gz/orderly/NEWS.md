# 0.3.4

* Support for creating "shiny apps" as artefacts
