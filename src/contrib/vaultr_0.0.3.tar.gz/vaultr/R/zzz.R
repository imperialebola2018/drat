vault_env <- new.env(parent = new.env())
vault_env$tokens <- new.env(parent = new.env())
